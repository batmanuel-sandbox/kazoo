.. _lock_module:

:mod:`kazoo.recipe.lock`
----------------------------

.. automodule:: kazoo.recipe.lock

Public API
++++++++++

    .. autoclass:: Lock
        :members:

        .. automethod:: __init__

    .. autoclass:: Semaphore
        :members:

        .. automethod:: __init__
